package com.medireminder.app

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.medireminder.app.data.AppDatabase
import com.medireminder.app.data.MediRepository
import com.medireminder.app.data.SettingsStore
import com.medireminder.app.reminders.AlarmScheduler
import com.medireminder.app.reminders.MaintenanceWorker
import com.medireminder.app.reminders.Notifier
import java.util.concurrent.TimeUnit

class MediReminderApp : Application() {
    lateinit var repo: MediRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repo = MediRepository(this, AppDatabase.get(this), SettingsStore(this), AlarmScheduler(this), Notifier(this))
        val work = PeriodicWorkRequestBuilder<MaintenanceWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this)
            .enqueueUniquePeriodicWork("maintenance", ExistingPeriodicWorkPolicy.KEEP, work)
    }
}
