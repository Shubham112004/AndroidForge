package com.medireminder.app.reminders

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.medireminder.app.MediReminderApp

/** Periodic housekeeping: marks missed doses, extends the schedule horizon, re-registers alarms. */
class MaintenanceWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        (applicationContext as MediReminderApp).repo.sync()
        return Result.success()
    }
}
