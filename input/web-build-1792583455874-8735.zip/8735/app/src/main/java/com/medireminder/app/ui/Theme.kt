package com.medireminder.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Light = lightColorScheme(
    primary = Color(0xFF0F766E), onPrimary = Color.White,
    primaryContainer = Color(0xFFCCEFEA), onPrimaryContainer = Color(0xFF00403B),
    secondaryContainer = Color(0xFFDDE8F5), onSecondaryContainer = Color(0xFF1B2B3F),
    background = Color(0xFFF6FAF9), onBackground = Color(0xFF16201F),
    surface = Color(0xFFFFFFFF), onSurface = Color(0xFF16201F),
    surfaceVariant = Color(0xFFE6EEEC), onSurfaceVariant = Color(0xFF3B4A48),
    errorContainer = Color(0xFFFCE0DC), onErrorContainer = Color(0xFF5C0E05)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FD6CB), onPrimary = Color(0xFF00201D),
    primaryContainer = Color(0xFF0B4D47), onPrimaryContainer = Color(0xFFCCEFEA),
    secondaryContainer = Color(0xFF2A3B52), onSecondaryContainer = Color(0xFFDDE8F5),
    background = Color(0xFF0E1514), onBackground = Color(0xFFE3EDEB),
    surface = Color(0xFF162120), onSurface = Color(0xFFE3EDEB),
    surfaceVariant = Color(0xFF2A3736), onSurfaceVariant = Color(0xFFC3D2CF),
    errorContainer = Color(0xFF5C1A12), onErrorContainer = Color(0xFFFFDAD4)
)

@Composable
fun MediTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
