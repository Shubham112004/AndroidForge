package com.medireminder.app.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.medireminder.app.MainActivity
import com.medireminder.app.R
import com.medireminder.app.data.AppSettings
import com.medireminder.app.data.DoseRecord
import com.medireminder.app.data.Fmt

class Notifier(private val ctx: Context) {

    // Channel sound/vibration cannot change after creation, so each combination gets its own channel.
    private fun channelFor(s: AppSettings): String {
        val id = "reminders_${if (s.sound) "s" else "q"}${if (s.vibrate) "v" else "n"}"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(id) == null) {
            val ch = NotificationChannel(id, "Medicine reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Reminders to take your medicines"
                enableVibration(s.vibrate)
                if (s.vibrate) vibrationPattern = longArrayOf(0, 300, 200, 300)
                if (!s.sound) setSound(null, null)
            }
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun show(r: DoseRecord, s: AppSettings) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val time = Fmt.time(r.scheduledAt)
        val body = buildString {
            append("Scheduled for $time")
            if (r.instructions.isNotBlank()) append("\n").append(r.instructions)
        }
        val n = NotificationCompat.Builder(ctx, channelFor(s))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("${r.medicineName} — ${r.doseText}")
            .setContentText("Scheduled for $time")
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setWhen(r.scheduledAt).setShowWhen(true)
            .setAutoCancel(false) // dismissing never marks a dose as taken
            .setContentIntent(open)
            .addAction(0, "Taken", actionPi(ctx, ActionReceiver.ACTION_TAKEN, r.id))
            .addAction(0, "Snooze ${s.snoozeMin} min", actionPi(ctx, ActionReceiver.ACTION_SNOOZE, r.id))
            .addAction(0, "Skip", actionPi(ctx, ActionReceiver.ACTION_SKIP, r.id))
            .build()
        try {
            nm.notify(r.id.toInt(), n)
        } catch (e: SecurityException) {
            // Notification permission missing; the dose stays visible in the app.
        }
    }

    fun cancel(id: Long) {
        NotificationManagerCompat.from(ctx).cancel(id.toInt())
    }

    companion object {
        fun actionPi(ctx: Context, action: String, id: Long): PendingIntent {
            val i = Intent(ctx, ActionReceiver::class.java)
                .setAction(action)
                .setData(Uri.parse("medireminder://action/$action/$id"))
                .putExtra(AlarmScheduler.EXTRA_ID, id)
            return PendingIntent.getBroadcast(ctx, id.toInt(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
    }
}
