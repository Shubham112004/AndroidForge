package com.medireminder.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicineDao {
    @Insert suspend fun insert(m: Medicine): Long
    @Update suspend fun update(m: Medicine)
    @Query("DELETE FROM medicines WHERE id = :id") suspend fun delete(id: Long)
    @Query("SELECT * FROM medicines ORDER BY name COLLATE NOCASE") fun observeAll(): Flow<List<Medicine>>
    @Query("SELECT * FROM medicines WHERE id = :id") fun observe(id: Long): Flow<Medicine?>
    @Query("SELECT * FROM medicines WHERE id = :id") suspend fun get(id: Long): Medicine?
    @Query("SELECT * FROM medicines WHERE active = 1") suspend fun getActive(): List<Medicine>
    @Query("UPDATE medicines SET stock = MAX(stock + :delta, 0) WHERE id = :id AND stock IS NOT NULL")
    suspend fun adjustStock(id: Long, delta: Double)
    @Query("UPDATE medicines SET stock = :stock WHERE id = :id") suspend fun setStock(id: Long, stock: Double?)
    @Query("UPDATE medicines SET active = :active, updatedAt = :now WHERE id = :id")
    suspend fun setActive(id: Long, active: Boolean, now: Long)
}

@Dao
interface ScheduleDao {
    @Insert suspend fun insert(s: Schedule): Long
    @Update suspend fun update(s: Schedule)
    @Query("SELECT * FROM schedules WHERE medicineId = :id") suspend fun forMedicine(id: Long): List<Schedule>
    @Query("SELECT * FROM schedules WHERE medicineId = :id LIMIT 1") fun observeForMedicine(id: Long): Flow<Schedule?>
    @Query("SELECT * FROM schedules") fun observeAll(): Flow<List<Schedule>>
    @Query("SELECT * FROM schedules WHERE enabled = 1") suspend fun enabledAll(): List<Schedule>
    @Query("UPDATE schedules SET effectiveFrom = :t WHERE medicineId = :id") suspend fun touch(id: Long, t: Long)
}

@Dao
interface DoseDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertIgnore(r: DoseRecord): Long
    @Insert suspend fun insertEvent(e: DoseEvent)

    @Query("SELECT * FROM dose_records WHERE id = :id") suspend fun get(id: Long): DoseRecord?
    @Query("SELECT * FROM dose_records WHERE status = 'PENDING'") suspend fun pending(): List<DoseRecord>
    @Query("SELECT * FROM dose_records WHERE status = 'PENDING' AND medicineId = :mid")
    suspend fun pendingForMedicine(mid: Long): List<DoseRecord>

    @Query(
        "SELECT * FROM dose_records WHERE status = 'PENDING' AND notifiedAt IS NULL " +
            "AND snoozedUntil IS NULL AND scheduledAt > :now AND (:mid IS NULL OR medicineId = :mid)"
    )
    suspend fun futureUnnotified(now: Long, mid: Long?): List<DoseRecord>

    @Query("DELETE FROM dose_records WHERE id IN (:ids)") suspend fun deleteByIds(ids: List<Long>)

    @Query("SELECT * FROM dose_records WHERE scheduledAt >= :from AND scheduledAt < :to ORDER BY scheduledAt, id")
    fun observeRange(from: Long, to: Long): Flow<List<DoseRecord>>

    @Query("SELECT * FROM dose_records WHERE medicineId = :mid AND status = 'PENDING' ORDER BY scheduledAt LIMIT 5")
    fun observeUpcoming(mid: Long): Flow<List<DoseRecord>>

    @Query("SELECT * FROM dose_records WHERE medicineId = :mid AND status != 'PENDING' ORDER BY scheduledAt DESC LIMIT 10")
    fun observeRecentHistory(mid: Long): Flow<List<DoseRecord>>

    @Query("SELECT * FROM dose_records WHERE scheduledAt >= :from AND scheduledAt < :to ORDER BY scheduledAt, id")
    suspend fun rangeList(from: Long, to: Long): List<DoseRecord>

    @Query("SELECT * FROM dose_events WHERE recordId = :id ORDER BY at") fun observeEvents(id: Long): Flow<List<DoseEvent>>

    @Query("UPDATE dose_records SET status = 'TAKEN', actedAt = :t, skipReason = NULL, snoozedUntil = NULL WHERE id = :id AND status = 'PENDING'")
    suspend fun takenIfPending(id: Long, t: Long): Int

    @Query("UPDATE dose_records SET status = 'SKIPPED', actedAt = :t, skipReason = :reason, snoozedUntil = NULL WHERE id = :id AND status = 'PENDING'")
    suspend fun skippedIfPending(id: Long, t: Long, reason: String?): Int

    @Query("UPDATE dose_records SET snoozedUntil = :until, notifiedAt = NULL WHERE id = :id AND status = 'PENDING'")
    suspend fun snooze(id: Long, until: Long): Int

    @Query("UPDATE dose_records SET notifiedAt = :t WHERE id = :id") suspend fun setNotified(id: Long, t: Long)

    @Query("UPDATE dose_records SET status = :status, actedAt = :t, skipReason = :reason, snoozedUntil = NULL WHERE id = :id")
    suspend fun setStatus(id: Long, status: String, t: Long?, reason: String?)

    @Query("SELECT id FROM dose_records WHERE status = 'PENDING' AND COALESCE(snoozedUntil, scheduledAt) + :graceMs < :now")
    suspend fun overdueIds(now: Long, graceMs: Long): List<Long>
}
