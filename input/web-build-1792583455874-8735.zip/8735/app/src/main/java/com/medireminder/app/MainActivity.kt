@file:OptIn(ExperimentalMaterial3Api::class)

package com.medireminder.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.medireminder.app.data.AppSettings
import com.medireminder.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = (application as MediReminderApp).repo
        setContent {
            val settings by repo.settings.flow.collectAsState(initial = AppSettings())
            val dark = when (settings.theme) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }
            MediTheme(dark) { MediApp() }
        }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("medicines", "Medicines", Icons.Filled.Medication),
    Tab("history", "History", Icons.Filled.History),
    Tab("settings", "Settings", Icons.Filled.Settings)
)

@Composable
fun MediApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val ctx = LocalContext.current

    // Explain and request the notification permission (Android 13+).
    var askNotif by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askNotif = false }
    if (askNotif) AlertDialog(
        onDismissRequest = { askNotif = false },
        title = { Text("Allow reminders?") },
        text = { Text("MediReminder needs permission to show notifications so it can remind you when a dose is due. You can change this later in Settings.") },
        confirmButton = { TextButton(onClick = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Continue") } },
        dismissButton = { TextButton(onClick = { askNotif = false }) { Text("Not now") } }
    )

    fun goTab(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        bottomBar = {
            if (TABS.any { it.route == route }) NavigationBar {
                TABS.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route, onClick = { goTab(t.route) },
                        icon = { Icon(t.icon, contentDescription = null) }, label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad).consumeWindowInsets(pad)) {
            composable("home") { HomeScreen(onAdd = { nav.navigate("edit/-1") }, onOpenSettings = { goTab("settings") }) }
            composable("medicines") { MedicinesScreen(onAdd = { nav.navigate("edit/-1") }, onOpen = { nav.navigate("details/$it") }) }
            composable("history") { HistoryScreen() }
            composable("settings") { SettingsScreen() }
            composable("details/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                DetailsScreen(onBack = { nav.popBackStack() }, onEdit = { nav.navigate("edit/$it") })
            }
            composable("edit/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                AddEditScreen(onBack = { nav.popBackStack() }, onSaved = { id ->
                    if (!nav.popBackStack()) nav.navigate("medicines")
                })
            }
        }
    }
}
