package com.medireminder.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.medireminder.app.data.ImageStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.ui.unit.dp

/** Shows the optional medicine photo; with placeholder = true an icon is shown when there is no photo. */
@Composable
fun MedicineImage(
    path: String?,
    modifier: Modifier = Modifier,
    decodePx: Int = 256,
    placeholder: Boolean = true,
    contentScale: ContentScale = ContentScale.Crop
) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, path, decodePx) {
        value = if (path == null) null else withContext(Dispatchers.IO) { ImageStore.decode(path, decodePx)?.asImageBitmap() }
    }
    val shape = RoundedCornerShape(14.dp)
    val bmp = bitmap
    if (bmp != null) {
        Image(bmp, contentDescription = "Photo of the medicine", contentScale = contentScale, modifier = modifier.clip(shape))
    } else if (placeholder) {
        Box(modifier.clip(shape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Medication, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}
