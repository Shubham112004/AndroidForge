package com.medireminder.app.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

/** Owns all AlarmManager access. One alarm per dose record; request code = record id. */
class AlarmScheduler(private val ctx: Context) {
    private val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun intent(id: Long) = Intent(ctx, AlarmReceiver::class.java)
        .setAction(ACTION_FIRE)
        .setData(Uri.parse("medireminder://dose/$id"))
        .putExtra(EXTRA_ID, id)

    private fun pi(id: Long, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(ctx, id.toInt(), intent(id), flags or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(id: Long, at: Long) {
        val p = pi(id, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        try {
            if (canExact(ctx)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p) // fallback: may be slightly late
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    fun cancel(id: Long) {
        pi(id, PendingIntent.FLAG_NO_CREATE)?.let { am.cancel(it); it.cancel() }
    }

    companion object {
        const val ACTION_FIRE = "com.medireminder.app.FIRE"
        const val EXTRA_ID = "dose_id"

        fun canExact(ctx: Context): Boolean =
            Build.VERSION.SDK_INT < 31 ||
                (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
    }
}
