@file:OptIn(ExperimentalMaterial3Api::class)

package com.medireminder.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medireminder.app.data.scheduleSummary

@Composable
fun MedicinesScreen(onAdd: () -> Unit, onOpen: (Long) -> Unit, vm: MedicinesViewModel = viewModel()) {
    val items by vm.items.collectAsState()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { TopAppBar(title = { Text("Medicines") }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add medicine") }) }
    ) { pad ->
        val list = items
        if (list != null && list.isEmpty()) {
            Box(Modifier.padding(pad).padding(24.dp).fillMaxSize()) {
                Text("You have not added any medicines yet. Tap \"Add medicine\" to start.", style = MaterialTheme.typography.bodyLarge)
            }
        } else LazyColumn(
            contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 8.dp, 16.dp, pad.calculateBottomPadding() + 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(list ?: emptyList(), key = { it.medicine.id }) { mw ->
                val m = mw.medicine
                Card(onClick = { onOpen(m.id) }, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    MedicineImage(m.imagePath, Modifier.size(56.dp), decodePx = 168)
                    Spacer(Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(m.name + if (m.strength.isNotBlank()) " ${m.strength}" else "", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("${m.doseAmount} ${m.doseUnit}", style = MaterialTheme.typography.bodyLarge)
                        Text(scheduleSummary(mw.schedule), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (!m.active) AssistChip(onClick = {}, label = { Text("Paused") })
                    }
                    }
                }
            }
        }
    }
}
