package com.medireminder.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.medireminder.app.data.DoseRecord
import com.medireminder.app.data.Fmt
import com.medireminder.app.data.MediRepository
import com.medireminder.app.data.Status
import com.medireminder.app.reminders.AlarmScheduler
import com.medireminder.app.reminders.AlarmService
import com.medireminder.app.ui.MediTheme
import com.medireminder.app.ui.MedicineImage
import kotlinx.coroutines.launch

/** Full-screen alarm shown over the lock screen when a dose is due. */
class AlarmActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        val repo = (application as MediReminderApp).repo
        setContent { MediTheme(isSystemInDarkTheme()) { AlarmScreen(id, repo) { finish() } } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }
}

@Composable
private fun AlarmScreen(id: Long, repo: MediRepository, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var rec by remember { mutableStateOf<DoseRecord?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var image by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(id) {
        rec = if (id >= 0) repo.getDose(id) else null
        image = rec?.let { repo.getMedicine(it.medicineId)?.imagePath }
        loaded = true
    }

    fun act(block: suspend () -> Unit) {
        scope.launch {
            block()
            AlarmService.stop(ctx)
            onClose()
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primaryContainer) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
        ) {
            val r = rec
            when {
                id == AlarmService.TEST_ID -> {
                    Text("Test alarm", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                    Text("If you can hear this, your medicine alarm works.", style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
                    Button(onClick = { act { } }, modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp)) { Text("Stop alarm", style = MaterialTheme.typography.titleLarge) }
                }
                !loaded -> CircularProgressIndicator()
                r == null || r.status != Status.PENDING -> {
                    Text("This dose is already recorded.", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                    Button(onClick = { act { } }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Close") }
                }
                else -> {
                    val d = r!!
                    Text("Time for your medicine", style = MaterialTheme.typography.titleMedium)
                    if (image != null) MedicineImage(image, Modifier.size(160.dp), decodePx = 480, placeholder = false)
                    Text(d.medicineName, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text(d.doseText, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                    Text("Scheduled for ${Fmt.time(d.scheduledAt)}", style = MaterialTheme.typography.titleMedium)
                    if (d.instructions.isNotBlank()) Text(d.instructions, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { act { repo.markTaken(d.id) } }, modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp)) {
                        Text("Taken", style = MaterialTheme.typography.headlineSmall)
                    }
                    Text("Snooze", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15).forEach { m ->
                            OutlinedButton(onClick = { act { repo.snooze(d.id, m) } }, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("$m min") }
                        }
                    }
                    OutlinedButton(onClick = { act { repo.skip(d.id, null) } }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Skip this dose") }
                }
            }
        }
    }
}
