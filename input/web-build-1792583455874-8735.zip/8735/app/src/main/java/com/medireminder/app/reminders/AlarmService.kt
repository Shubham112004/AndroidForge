package com.medireminder.app.reminders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.medireminder.app.AlarmActivity
import com.medireminder.app.MediReminderApp
import com.medireminder.app.R
import com.medireminder.app.data.AppSettings
import com.medireminder.app.data.Fmt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Rings a loud alarm (alarm volume stream, looping, with vibration) and opens a full-screen
 * screen over the lock screen. It stops when the user answers, or after 2 minutes, after which
 * the alarm optionally rings again (re-ring) until the missed-dose grace period ends.
 */
class AlarmService : Service() {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var ringingId: Long? = null
    private var currentNotification: Notification? = null
    private var timeout: Runnable? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        val name = intent.getStringExtra("name") ?: "Medicine"
        val dose = intent.getStringExtra("dose") ?: ""
        val at = intent.getLongExtra("at", System.currentTimeMillis())
        val info = intent.getStringExtra("info") ?: ""
        val notification = buildNotification(id, name, dose, at, info)

        val busy = ringingId
        if (busy != null && busy != id) {
            // Already ringing for another dose: keep the service running and post this one as a notification.
            currentNotification?.let { startForegroundCompat(notifId(busy), it) }
            try { NotificationManagerCompat.from(this).notify(notifId(id), notification) } catch (e: SecurityException) { }
            return START_NOT_STICKY
        }
        startForegroundCompat(notifId(id), notification)
        currentNotification = notification
        if (busy == id) return START_NOT_STICKY

        ringingId = id
        if (intent.getBooleanExtra("sound", true)) startSound(intent.getStringExtra("tone") ?: "")
        if (intent.getBooleanExtra("vibrate", true)) startVibration()

        val reRing = intent.getBooleanExtra("rering", true)
        val snoozeMin = intent.getIntExtra("snooze", 5)
        val r = Runnable { onTimeout(id, reRing, snoozeMin) }
        timeout = r
        handler.postDelayed(r, RING_MS)
        return START_NOT_STICKY
    }

    private fun onTimeout(id: Long, reRing: Boolean, snoozeMin: Int) {
        stopRinging()
        if (id >= 0 && reRing) {
            val repo = (application as MediReminderApp).repo
            scope.launch { repo.reRing(id, snoozeMin) }
        }
        stopForeground(if (id == TEST_ID) STOP_FOREGROUND_REMOVE else STOP_FOREGROUND_DETACH)
        stopSelf()
    }

    private fun startForegroundCompat(nid: Int, n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) startForeground(nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(nid, n)
    }

    private fun startSound(tone: String) {
        val uris = mutableListOf<Uri>()
        if (tone.isNotBlank()) uris += Uri.parse(tone)
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.let { uris += it }
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)?.let { uris += it }
        for (u in uris) {
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                )
                mp.setDataSource(this, u)
                mp.isLooping = true
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (e: Exception) {
                // try the next fallback sound
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator? = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    private fun startVibration() {
        try {
            vibrator()?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
        } catch (e: Exception) { }
    }

    private fun stopRinging() {
        timeout?.let { handler.removeCallbacks(it) }
        timeout = null
        player?.let { try { it.stop() } catch (e: Exception) { }; it.release() }
        player = null
        try { vibrator()?.cancel() } catch (e: Exception) { }
        ringingId = null
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }

    private fun ensureChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Medicine alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Full-screen alarm when a dose is due"
                setSound(null, null)   // the service plays the alarm sound itself
                enableVibration(false)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(id: Long, name: String, dose: String, at: Long, info: String): Notification {
        ensureChannel()
        val screen = PendingIntent.getActivity(
            this, notifId(id),
            Intent(this, AlarmActivity::class.java).putExtra(AlarmScheduler.EXTRA_ID, id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (id == TEST_ID) "This is a test of your medicine alarm" else "$dose · ${Fmt.time(at)}"
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(if (id == TEST_ID) "Test alarm" else "Time to take $name")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (info.isBlank()) text else "$text\n$info"))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(screen, true)
            .setContentIntent(screen)
        if (id == TEST_ID) {
            b.addAction(0, "Stop", Notifier.actionPi(this, ActionReceiver.ACTION_TAKEN, id))
        } else {
            b.addAction(0, "Taken", Notifier.actionPi(this, ActionReceiver.ACTION_TAKEN, id))
            b.addAction(0, "Snooze", Notifier.actionPi(this, ActionReceiver.ACTION_SNOOZE, id))
            b.addAction(0, "Skip", Notifier.actionPi(this, ActionReceiver.ACTION_SKIP, id))
        }
        return b.build()
    }

    companion object {
        const val TEST_ID = -2L
        private const val CHANNEL = "alarm_v1"
        private const val RING_MS = 120_000L

        fun notifId(id: Long): Int = if (id == TEST_ID) 424242 else id.toInt()

        /** Returns false if Android refused to start the service; the caller then falls back to a notification. */
        fun start(ctx: Context, id: Long, name: String, dose: String, at: Long, info: String, s: AppSettings): Boolean {
            val i = Intent(ctx, AlarmService::class.java)
                .putExtra(AlarmScheduler.EXTRA_ID, id)
                .putExtra("name", name).putExtra("dose", dose).putExtra("at", at).putExtra("info", info)
                .putExtra("sound", s.sound).putExtra("vibrate", s.vibrate)
                .putExtra("tone", s.alarmTone).putExtra("rering", s.reRing).putExtra("snooze", s.snoozeMin)
            return try { ContextCompat.startForegroundService(ctx, i); true } catch (e: Exception) { false }
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, AlarmService::class.java)) }
    }
}
