package com.medireminder.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

data class AppSettings(
    val sound: Boolean = true,
    val vibrate: Boolean = true,
    val snoozeMin: Int = 10,
    val graceMin: Int = 60,
    val theme: String = "SYSTEM", // SYSTEM, LIGHT, DARK
    val alarmMode: Boolean = true, // ring a full-screen alarm instead of a plain notification
    val reRing: Boolean = true,    // ring again if the alarm is not answered
    val alarmTone: String = ""     // empty = default alarm sound
)

class SettingsStore(private val ctx: Context) {
    private object K {
        val SOUND = booleanPreferencesKey("sound")
        val VIBRATE = booleanPreferencesKey("vibrate")
        val SNOOZE = intPreferencesKey("snooze_min")
        val GRACE = intPreferencesKey("grace_min")
        val THEME = stringPreferencesKey("theme")
        val ALARM = booleanPreferencesKey("alarm_mode")
        val RERING = booleanPreferencesKey("re_ring")
        val TONE = stringPreferencesKey("alarm_tone")
    }

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            sound = p[K.SOUND] ?: true,
            vibrate = p[K.VIBRATE] ?: true,
            snoozeMin = p[K.SNOOZE] ?: 10,
            graceMin = p[K.GRACE] ?: 60,
            theme = p[K.THEME] ?: "SYSTEM",
            alarmMode = p[K.ALARM] ?: true,
            reRing = p[K.RERING] ?: true,
            alarmTone = p[K.TONE] ?: ""
        )
    }

    suspend fun current(): AppSettings = flow.first()
    suspend fun setSound(v: Boolean) { ctx.dataStore.edit { it[K.SOUND] = v } }
    suspend fun setVibrate(v: Boolean) { ctx.dataStore.edit { it[K.VIBRATE] = v } }
    suspend fun setSnooze(v: Int) { ctx.dataStore.edit { it[K.SNOOZE] = v } }
    suspend fun setGrace(v: Int) { ctx.dataStore.edit { it[K.GRACE] = v } }
    suspend fun setTheme(v: String) { ctx.dataStore.edit { it[K.THEME] = v } }
    suspend fun setAlarmMode(v: Boolean) { ctx.dataStore.edit { it[K.ALARM] = v } }
    suspend fun setReRing(v: Boolean) { ctx.dataStore.edit { it[K.RERING] = v } }
    suspend fun setAlarmTone(v: String) { ctx.dataStore.edit { it[K.TONE] = v } }
}
