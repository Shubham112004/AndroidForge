@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.medireminder.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.medireminder.app.data.*
import kotlinx.coroutines.flow.Flow

@Composable
fun StatusChip(status: String, due: Boolean = false) {
    val (label, icon, container) = when (status) {
        Status.TAKEN -> Triple("Taken", Icons.Filled.CheckCircle, MaterialTheme.colorScheme.primaryContainer)
        Status.SKIPPED -> Triple("Skipped", Icons.Filled.SkipNext, MaterialTheme.colorScheme.secondaryContainer)
        Status.MISSED -> Triple("Missed", Icons.Filled.Warning, MaterialTheme.colorScheme.errorContainer)
        else -> Triple(if (due) "Due now" else "Upcoming", Icons.Filled.Schedule, MaterialTheme.colorScheme.surfaceVariant)
    }
    Surface(color = container, shape = RoundedCornerShape(50)) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 8.dp))
}

@Composable
fun DoseCard(r: DoseRecord, now: Long, showDate: Boolean = false, imagePath: String? = null, onClick: () -> Unit, onTaken: () -> Unit) {
    Card(
        onClick = onClick, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (imagePath != null) {
                    MedicineImage(imagePath, Modifier.size(48.dp), decodePx = 144, placeholder = false)
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(r.medicineName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(r.doseText, style = MaterialTheme.typography.bodyLarge)
                }
                StatusChip(r.status, due = r.status == Status.PENDING && r.fireTime() <= now)
            }
            Text(
                "Scheduled: " + if (showDate) Fmt.dateTime(r.scheduledAt) else Fmt.time(r.scheduledAt),
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (r.status == Status.PENDING && r.snoozedUntil != null)
                Text("Snoozed until ${Fmt.time(r.snoozedUntil)}", style = MaterialTheme.typography.bodyMedium)
            if (r.status == Status.TAKEN && r.actedAt != null)
                Text("Confirmed at ${Fmt.time(r.actedAt)}", style = MaterialTheme.typography.bodyMedium)
            if (r.status == Status.SKIPPED) {
                val reason = r.skipReason?.let { " — Reason: $it" } ?: ""
                Text("Skipped$reason", style = MaterialTheme.typography.bodyMedium)
            }
            if (r.instructions.isNotBlank())
                Text(r.instructions, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (r.status == Status.PENDING) {
                Button(
                    onClick = onTaken,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        .semantics { contentDescription = "Mark ${r.medicineName} as taken" }
                ) { Text("Taken") }
            }
        }
    }
}

@Composable
fun DoseDialog(
    r: DoseRecord,
    events: Flow<List<DoseEvent>>,
    onDismiss: () -> Unit,
    onTaken: () -> Unit,
    onSnooze: (Int) -> Unit,
    onSkip: (String) -> Unit,
    onCorrect: (String, String?) -> Unit
) {
    val log by remember(r.id) { events }.collectAsState(initial = emptyList())
    var reason by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) { Text("Close") } },
        title = { Text("${r.medicineName} — ${r.doseText}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Scheduled: ${Fmt.dateTime(r.scheduledAt)}")
                if (r.actedAt != null) Text("Recorded at: ${Fmt.dateTime(r.actedAt)}")
                if (r.instructions.isNotBlank()) Text(r.instructions, style = MaterialTheme.typography.bodySmall)
                if (r.status == Status.PENDING) {
                    Button(onClick = onTaken, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Mark as taken") }
                    Text("Snooze", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15).forEach { m ->
                            OutlinedButton(onClick = { onSnooze(m) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("$m min") }
                        }
                    }
                    OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Reason for skipping (optional)") },
                        modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { onSkip(reason) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Skip this dose") }
                } else {
                    Text("Current status: ${r.status.lowercase().replaceFirstChar { it.uppercase() }}", fontWeight = FontWeight.SemiBold)
                    Text("Recorded the wrong action? Change it below. The earlier status is kept in the log.", style = MaterialTheme.typography.bodySmall)
                    if (r.status != Status.TAKEN) OutlinedButton(onClick = { onCorrect(Status.TAKEN, null) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Change to Taken") }
                    if (r.status != Status.SKIPPED) {
                        OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("Skip reason (optional)") }, modifier = Modifier.fillMaxWidth())
                        OutlinedButton(onClick = { onCorrect(Status.SKIPPED, reason) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Change to Skipped") }
                    }
                    if (r.status != Status.MISSED) OutlinedButton(onClick = { onCorrect(Status.MISSED, null) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Change to Missed") }
                    if (r.status == Status.MISSED)
                        Text("If you missed a dose, follow your prescription instructions or ask your doctor or pharmacist what to do. Do not take extra to make up for it.",
                            style = MaterialTheme.typography.bodySmall)
                }
                if (log.isNotEmpty()) {
                    Text("Change log", fontWeight = FontWeight.SemiBold)
                    log.forEach { e ->
                        Text("${e.fromStatus.lowercase()} → ${e.toStatus.lowercase()} at ${Fmt.time(e.at)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    )
}

@Composable
fun DropdownField(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedTextField(
            value = value, onValueChange = {}, readOnly = true, label = { Text(label) },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
            modifier = Modifier.fillMaxWidth()
        )
        Box(
            Modifier.matchParentSize().clickable { expanded = true }
                .semantics { role = Role.DropdownList; contentDescription = "$label: $value. Double tap to change." }
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onSelect(o); expanded = false }) }
        }
    }
}
