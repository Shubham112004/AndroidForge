package com.medireminder.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Stores optional medicine photos in the app's private storage (never shared, removed on uninstall). */
object ImageStore {
    private const val MAX_SIDE = 1024

    private fun dir(ctx: Context): File = File(ctx.filesDir, "medicine_images").apply { mkdirs() }

    /** Copies, rotates and downsizes the picked image. Returns the saved file path, or null on failure. */
    fun save(ctx: Context, uri: Uri): String? {
        return try {
            val resolver = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / sample > MAX_SIDE * 2 || bounds.outHeight / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val orientation = resolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL

            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            }
            val longest = maxOf(decoded.width, decoded.height)
            if (longest > MAX_SIDE) {
                val s = MAX_SIDE.toFloat() / longest
                m.postScale(s, s)
            }
            val out: Bitmap = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
            val file = File(dir(ctx), "${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /** Only deletes files inside our own image folder. */
    fun delete(ctx: Context, path: String?) {
        if (path == null) return
        try {
            val f = File(path)
            if (f.canonicalPath.startsWith(dir(ctx).canonicalPath)) f.delete()
        } catch (e: Exception) { }
    }

    /** Decodes a saved image at roughly the requested size (for display). */
    fun decode(path: String, reqPx: Int): Bitmap? {
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, b)
            var sample = 1
            while (b.outWidth / (sample * 2) >= reqPx && b.outHeight / (sample * 2) >= reqPx) sample *= 2
            BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }
}
