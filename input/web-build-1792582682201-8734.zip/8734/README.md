# MediReminder (V1)

Offline medicine reminder app. Kotlin, Jetpack Compose, Material 3, MVVM, Room, DataStore,
Coroutines/Flow, Navigation Compose, AlarmManager, NotificationManager, WorkManager.
No backend, no account, no internet permission.

## Build

Requirements: Android Studio (Koala or newer) or JDK 17+ with Android SDK 35 installed.

**Android Studio (recommended):** File > Open > select this folder, let Gradle sync,
then Run, or Build > Build APK(s).

**Command line:**
1. Create `local.properties` with `sdk.dir=/path/to/Android/sdk`.
2. This archive has no Gradle wrapper JAR. With Gradle 8.9+ installed run `gradle wrapper --gradle-version 8.9` once.
3. `./gradlew assembleDebug`
4. APK: `app/build/outputs/apk/debug/app-debug.apk`
   (`assembleRelease` also works; it is signed with the debug key for testing.)

Install: `adb install -r app/build/outputs/apk/debug/app-debug.apk`

## What's new in 1.1
* **Real alarm**: a foreground service rings the alarm sound (alarm volume, looping, with vibration) and opens a
  full-screen screen over the lock screen with Taken / Snooze (5, 10, 15) / Skip. Stops when answered or after 2 minutes;
  if unanswered it rings again after the snooze length until the missed-dose grace period ends.
* Settings > Alarm: switch alarm vs notification-only, re-ring, choose alarm sound, **Test alarm now**,
  full-screen permission status (Android 14+).
* **Refill tracker**: optional stock per medicine; each taken dose reduces it; "Time to refill" card on Home.
* **Consistency**: 7-day / 30-day percentage and streak on History.
* **Share report**: 30-day text report via any app (for your doctor).
* Database migrated 1 -> 2 without losing data.

## How reminders work
* Each scheduled dose is a row in `dose_records` with a unique occurrence id
  (`scheduleId-epochDay-minute`). Rows for today and the next 2 days are generated on demand.
* One alarm per pending dose (request code = record id), so duplicates cannot occur.
  Exact alarms are used when allowed; otherwise inexact `setAndAllowWhileIdle` (may be a few minutes late).
* Notification buttons (Taken / Snooze / Skip) are broadcast receivers and work with the app closed.
* Reboot, app update, clock and time-zone changes and exact-alarm permission changes trigger a resync.
  After being offline, at most 3 overdue reminders are shown; older ones stay on the dashboard.
* A 15-minute WorkManager job marks doses missed and extends the schedule window (it does not replace the alarms).
* Status corrections are written to `dose_events`; original statuses are never silently overwritten.
* Edits regenerate only future, not-yet-notified doses. Records keep a snapshot of name and dose.

## Known limitations
* Custom alarm sounds from outside the system list may not play on some phones; it falls back to the default alarm sound.
* If the phone is on silent/Do Not Disturb the alarm may be muted by the system.
* Not compiled or run in the environment that produced this project (no Android SDK or network there).
  Expect to fix small compile errors on first build.
* The notification Snooze button uses the default snooze length from Settings; the 5/10/15 minute choices
  are in the dose dialog (tap a dose in the app).
* Notification Skip records no reason; add one by changing the status in the app.
* App settings are stored in DataStore (not a Room table).
* Some phone makers kill background apps; Settings links to the battery optimization screen.
* Deleting a medicine also deletes its history (pause it to keep history).
