package com.medireminder.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Medicine::class, Schedule::class, DoseRecord::class, DoseEvent::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun doseDao(): DoseDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        // V1.1: optional stock tracking. Existing data is kept.
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE medicines ADD COLUMN stock REAL")
                db.execSQL("ALTER TABLE medicines ADD COLUMN refillDoses INTEGER NOT NULL DEFAULT 5")
            }
        }

        fun get(ctx: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "medireminder.db")
                .addMigrations(MIGRATION_1_2)
                .build().also { instance = it }
        }
    }
}
