package com.medireminder.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.medireminder.app.MediReminderApp
import com.medireminder.app.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.roundToInt

abstract class BaseViewModel(app: Application) : AndroidViewModel(app) {
    protected val repo: MediRepository = (app as MediReminderApp).repo
}

abstract class DoseViewModel(app: Application) : BaseViewModel(app) {
    fun taken(id: Long) { viewModelScope.launch { repo.markTaken(id) } }
    fun snooze(id: Long, min: Int) { viewModelScope.launch { repo.snooze(id, min) } }
    fun skip(id: Long, reason: String) { viewModelScope.launch { repo.skip(id, reason) } }
    fun correct(id: Long, status: String, reason: String?) { viewModelScope.launch { repo.correct(id, status, reason) } }
    fun events(id: Long): Flow<List<DoseEvent>> = repo.observeEvents(id)
}

class HomeViewModel(app: Application) : DoseViewModel(app) {
    private val _now = MutableStateFlow(System.currentTimeMillis())
    val now: StateFlow<Long> = _now

    init {
        viewModelScope.launch {
            while (true) {
                repo.sync()
                _now.value = System.currentTimeMillis()
                delay(30_000)
            }
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val doses: StateFlow<List<DoseRecord>> = _now
        .map { LocalDate.now() }
        .distinctUntilChanged()
        .flatMapLatest { d -> repo.observeDoses(dayStartMillis(d), dayStartMillis(d.plusDays(2))) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val medicineCount: StateFlow<Int> = repo.medicines.map { it.size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), -1)

    val lowStock: StateFlow<List<String>> = repo.medicines.map { list ->
        list.filter { it.active }.mapNotNull { m ->
            val left = m.dosesLeft()
            if (left != null && left <= m.refillDoses) "${m.name}: about $left dose${if (left == 1) "" else "s"} left" else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

data class MedWithSchedule(val medicine: Medicine, val schedule: Schedule?)

class MedicinesViewModel(app: Application) : BaseViewModel(app) {
    val items: StateFlow<List<MedWithSchedule>?> = combine(repo.medicines, repo.schedules) { meds, scs ->
        meds.map { m -> MedWithSchedule(m, scs.firstOrNull { it.medicineId == m.id }) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}

class DetailsViewModel(app: Application, handle: SavedStateHandle) : DoseViewModel(app) {
    val id: Long = handle.get<Long>("id") ?: -1L
    val medicine = repo.observeMedicine(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val schedule = repo.observeSchedule(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val upcoming = repo.observeUpcoming(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val history = repo.observeRecentHistory(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setActive(active: Boolean) { viewModelScope.launch { repo.setActive(id, active) } }
    fun setStock(v: Double?) { viewModelScope.launch { repo.setStock(id, v) } }
    fun delete(onDone: () -> Unit) { viewModelScope.launch { repo.deleteMedicine(id); onDone() } }
}

data class Stats(val week: Int?, val month: Int?, val streak: Int)

private fun computeStats(all: List<DoseRecord>): Stats {
    val today = LocalDate.now()
    fun pct(days: Long): Int? {
        val from = dayStartMillis(today.minusDays(days - 1))
        val rs = all.filter { it.scheduledAt >= from && it.status != Status.PENDING }
        if (rs.isEmpty()) return null
        return (rs.count { it.status == Status.TAKEN } * 100f / rs.size).roundToInt()
    }
    var streak = 0
    for (i in 0L..29L) {
        val d = today.minusDays(i)
        val day = all.filter { Fmt.localDate(it.scheduledAt) == d }
        if (day.isEmpty()) continue
        if (i == 0L && day.any { it.status == Status.PENDING }) continue // today is still in progress
        if (day.any { it.status != Status.TAKEN }) break
        streak++
    }
    return Stats(pct(7), pct(30), streak)
}

private data class HistoryQuery(val date: LocalDate, val weekly: Boolean, val medicineId: Long?)

class HistoryViewModel(app: Application) : DoseViewModel(app) {
    val date = MutableStateFlow(LocalDate.now())
    val weekly = MutableStateFlow(false)
    val filter = MutableStateFlow<Long?>(null)
    val medicines = repo.medicines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val records: StateFlow<List<DoseRecord>> =
        combine(date, weekly, filter) { d, w, f -> HistoryQuery(d, w, f) }
            .flatMapLatest { q ->
                val from = if (q.weekly) mondayOf(q.date) else q.date
                val to = if (q.weekly) from.plusDays(7) else from.plusDays(1)
                repo.observeDoses(dayStartMillis(from), dayStartMillis(to)).map { list ->
                    if (q.medicineId == null) list else list.filter { it.medicineId == q.medicineId }
                }
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stats: StateFlow<Stats?> = repo.observeDoses(
        dayStartMillis(LocalDate.now().minusDays(29)), dayStartMillis(LocalDate.now().plusDays(1))
    ).map { computeStats(it) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun report(onText: (String) -> Unit) { viewModelScope.launch { onText(repo.reportText(30)) } }

    fun shift(direction: Int) {
        date.value = date.value.plusDays(direction * (if (weekly.value) 7L else 1L))
    }
}

class SettingsViewModel(app: Application) : BaseViewModel(app) {
    val settings = repo.settings.flow.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())
    fun sound(v: Boolean) { viewModelScope.launch { repo.settings.setSound(v) } }
    fun vibrate(v: Boolean) { viewModelScope.launch { repo.settings.setVibrate(v) } }
    fun snooze(v: Int) { viewModelScope.launch { repo.settings.setSnooze(v) } }
    fun alarmMode(v: Boolean) { viewModelScope.launch { repo.settings.setAlarmMode(v) } }
    fun reRing(v: Boolean) { viewModelScope.launch { repo.settings.setReRing(v) } }
    fun tone(v: String) { viewModelScope.launch { repo.settings.setAlarmTone(v) } }
    fun theme(v: String) { viewModelScope.launch { repo.settings.setTheme(v) } }
    fun grace(v: Int) { viewModelScope.launch { repo.settings.setGrace(v); repo.sync() } }
}

class AddEditViewModel(app: Application, handle: SavedStateHandle) : BaseViewModel(app) {
    val id: Long = handle.get<Long>("id") ?: -1L

    var name by mutableStateOf("")
    var strength by mutableStateOf("")
    var form by mutableStateOf("Tablet")
    var amount by mutableStateOf("")
    var unit by mutableStateOf("")
    var food by mutableStateOf("Unspecified")
    var notes by mutableStateOf("")
    var stock by mutableStateOf("")
    var refill by mutableStateOf("5")
    var frequency by mutableStateOf("DAILY")
    var mask by mutableIntStateOf(0)
    val times = mutableStateListOf<Int>()
    var startDate by mutableStateOf(LocalDate.now())
    var hasEnd by mutableStateOf(false)
    var endDate by mutableStateOf(LocalDate.now().plusDays(7))
    var errors by mutableStateOf<Map<String, String>>(emptyMap())
    var saving by mutableStateOf(false)
    var loaded by mutableStateOf(id <= 0)
    private var original: Medicine? = null

    init {
        if (id > 0) viewModelScope.launch {
            val m = repo.getMedicine(id)
            val s = repo.getSchedule(id)
            if (m != null) {
                original = m
                name = m.name; strength = m.strength; form = m.form
                amount = m.doseAmount; unit = m.doseUnit; food = m.food; notes = m.notes
                stock = m.stock?.let { fmtQty(it) } ?: ""; refill = m.refillDoses.toString()
                startDate = LocalDate.ofEpochDay(m.startDay)
                m.endDay?.let { hasEnd = true; endDate = LocalDate.ofEpochDay(it) }
            }
            if (s != null) {
                frequency = s.frequency; mask = s.weekdaysMask
                times.clear(); times.addAll(s.times())
            }
            loaded = true
        }
    }

    fun toggleDay(i: Int) { mask = mask xor (1 shl i) }

    fun addTime(min: Int) {
        if (min !in times) { times.add(min); times.sort() }
    }

    private fun validate(): Boolean {
        val e = mutableMapOf<String, String>()
        if (name.isBlank()) e["name"] = "Enter the medicine name."
        val amt = amount.trim()
        if (amt.isEmpty()) e["amount"] = "Enter the amount to take, for example 1 or 5."
        else if (!Regex("""^\d+([.,]\d+)?(\s*/\s*\d+)?$""").matches(amt) || amt.all { it == '0' || it == '.' || it == ',' })
            e["amount"] = "Use a number greater than zero, such as 1, 0.5 or 1/2."
        if (unit.isBlank()) e["unit"] = "Enter the unit, for example tablet or mL."
        if (stock.isNotBlank() && (stock.trim().replace(',', '.').toDoubleOrNull() ?: -1.0) < 0.0) e["stock"] = "Enter the stock as a number, or leave it empty."
        if (times.isEmpty()) e["times"] = "Add at least one reminder time."
        if (frequency == "WEEKDAYS" && mask == 0) e["days"] = "Select at least one weekday."
        if (hasEnd && endDate.isBefore(startDate)) e["end"] = "The end date cannot be before the start date."
        errors = e
        return e.isEmpty()
    }

    fun save(onDone: (Long) -> Unit) {
        if (saving || !validate()) return
        saving = true
        viewModelScope.launch {
            val o = original
            val m = Medicine(
                id = if (id > 0) id else 0,
                name = name.trim(), strength = strength.trim(), form = form,
                doseAmount = amount.trim(), doseUnit = unit.trim(), food = food, notes = notes.trim(),
                startDay = startDate.toEpochDay(), endDay = if (hasEnd) endDate.toEpochDay() else null,
                active = o?.active ?: true, createdAt = o?.createdAt ?: 0, updatedAt = 0,
                stock = stock.trim().replace(',', '.').toDoubleOrNull(),
                refillDoses = refill.trim().toIntOrNull()?.coerceAtLeast(1) ?: 5
            )
            val savedId = repo.saveMedicine(m, ScheduleInput(frequency, if (frequency == "DAILY") 127 else mask, times.toList()))
            saving = false
            onDone(savedId)
        }
    }
}
