@file:OptIn(ExperimentalMaterial3Api::class)

package com.medireminder.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medireminder.app.data.*

@Composable
private fun InfoRow(label: String, value: String) {
    if (value.isBlank()) return
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun DetailsScreen(onBack: () -> Unit, onEdit: (Long) -> Unit, vm: DetailsViewModel = viewModel()) {
    val med by vm.medicine.collectAsState()
    val sched by vm.schedule.collectAsState()
    val upcoming by vm.upcoming.collectAsState()
    val history by vm.history.collectAsState()
    var confirmDelete by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var showStock by remember { mutableStateOf(false) }
    var stockText by remember { mutableStateOf("") }
    val now = System.currentTimeMillis()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = { Text("Medicine details") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
        }
    ) { pad ->
        val m = med
        if (m == null) {
            Box(Modifier.padding(pad).padding(24.dp)) { Text("This medicine is no longer available.") }
            return@Scaffold
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 8.dp, 16.dp, pad.calculateBottomPadding() + 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp).fillMaxWidth()) {
                        Text(m.name, style = MaterialTheme.typography.headlineSmall)
                        if (!m.active) AssistChip(onClick = {}, label = { Text("Paused — no reminders") })
                        InfoRow("Strength (the amount in each unit)", m.strength)
                        InfoRow("Dose to take", "${m.doseAmount} ${m.doseUnit}")
                        InfoRow("Form", m.form)
                        InfoRow("Schedule", scheduleSummary(sched))
                        InfoRow("Start date", Fmt.epochDay(m.startDay))
                        InfoRow("End date", m.endDay?.let { Fmt.epochDay(it) } ?: "Ongoing")
                        InfoRow("Food instructions", if (m.food == "Unspecified") "" else m.food)
                        InfoRow("Notes", m.notes)
                        InfoRow("Stock", m.stock?.let { "${fmtQty(it)} ${m.doseUnit} (about ${m.dosesLeft() ?: 0} doses)" } ?: "")
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { onEdit(m.id) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("Edit") }
                    OutlinedButton(onClick = { vm.setActive(!m.active) }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
                        Text(if (m.active) "Pause" else "Resume")
                    }
                    OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) { Text("Delete") }
                }
            }
            item {
                OutlinedButton(
                    onClick = { stockText = m.stock?.let { fmtQty(it) } ?: ""; showStock = true },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
                ) { Text(if (m.stock == null) "Track stock / refills" else "Update stock (e.g. after a refill)") }
            }
            item { SectionTitle("Upcoming reminders") }
            if (upcoming.isEmpty()) item { Text(if (m.active) "No upcoming reminders in the next few days." else "Paused.") }
            items(upcoming, key = { "u${it.id}" }) { r -> DoseCard(r, now, showDate = true, onClick = { selectedId = r.id }, onTaken = { vm.taken(r.id) }) }
            item { SectionTitle("Recent history") }
            if (history.isEmpty()) item { Text("No dose history yet.") }
            items(history, key = { "h${it.id}" }) { r -> DoseCard(r, now, showDate = true, onClick = { selectedId = r.id }, onTaken = {}) }
        }
    }

    if (showStock) AlertDialog(
        onDismissRequest = { showStock = false },
        title = { Text("Stock on hand") },
        text = {
            OutlinedTextField(
                value = stockText, onValueChange = { stockText = it }, singleLine = true,
                label = { Text("Amount left (${med?.doseUnit ?: "units"})") },
                supportingText = { Text("Leave empty to stop tracking. Each taken dose reduces it.") }
            )
        },
        confirmButton = {
            TextButton(onClick = {
                vm.setStock(stockText.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it >= 0 })
                showStock = false
            }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = { showStock = false }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Cancel") } }
    )

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete this medicine?") },
        text = { Text("This removes the medicine, its reminders and its dose history from this phone. This cannot be undone. To keep the history, pause the medicine instead.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(onBack) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Cancel") } }
    )

    (upcoming + history).find { it.id == selectedId }?.let { r ->
        DoseDialog(r, vm.events(r.id), onDismiss = { selectedId = null },
            onTaken = { vm.taken(r.id); selectedId = null },
            onSnooze = { vm.snooze(r.id, it); selectedId = null },
            onSkip = { vm.skip(r.id, it); selectedId = null },
            onCorrect = { s, reason -> vm.correct(r.id, s, reason); selectedId = null })
    }
}
