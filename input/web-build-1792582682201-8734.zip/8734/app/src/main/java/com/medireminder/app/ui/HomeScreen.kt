@file:OptIn(ExperimentalMaterial3Api::class)

package com.medireminder.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medireminder.app.data.*
import com.medireminder.app.reminders.AlarmScheduler
import java.time.LocalDate

@Composable
fun HomeScreen(onAdd: () -> Unit, onOpenSettings: () -> Unit, vm: HomeViewModel = viewModel()) {
    val doses by vm.doses.collectAsState()
    val now by vm.now.collectAsState()
    val count by vm.medicineCount.collectAsState()
    val low by vm.lowStock.collectAsState()
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val ctx = LocalContext.current
    val notifOn = NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    val exactOn = AlarmScheduler.canExact(ctx)

    val today = LocalDate.now()
    val tomorrowStart = dayStartMillis(today.plusDays(1))
    val todays = doses.filter { it.scheduledAt < tomorrowStart }
    val pending = doses.filter { it.status == Status.PENDING }.sortedBy { it.fireTime() }
    val next = pending.firstOrNull()
    val upcoming = pending.drop(1).take(3)
    val taken = todays.count { it.status == Status.TAKEN }
    val greeting = java.time.LocalTime.now().hour.let { if (it < 12) "Good morning" else if (it < 17) "Good afternoon" else "Good evening" }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add medicine") })
        }
    ) { pad ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 8.dp, 16.dp, pad.calculateBottomPadding() + 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(greeting, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(Fmt.date(today), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!notifOn || !exactOn) item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            if (!notifOn) "Notifications are turned off, so reminders will not appear."
                            else "Exact alarms are not allowed. Reminders may arrive a few minutes late.",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Button(onClick = onOpenSettings, modifier = Modifier.heightIn(min = 48.dp)) { Text("Open reminder settings") }
                    }
                }
            }
            if (low.isNotEmpty()) item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Time to refill", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        low.forEach { Text(it, style = MaterialTheme.typography.bodyLarge) }
                    }
                }
            }
            if (count == 0) item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("No medicines yet", style = MaterialTheme.typography.titleLarge)
                        Text("Add a medicine, enter the dose from your prescription, and choose reminder times.", style = MaterialTheme.typography.bodyLarge)
                        Button(onClick = onAdd, modifier = Modifier.heightIn(min = 48.dp)) { Text("Add your first medicine") }
                    }
                }
            } else if (count > 0) {
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Next medicine", style = MaterialTheme.typography.labelLarge)
                            if (next != null) {
                                Text(next.medicineName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("${next.doseText} · ${if (Fmt.localDate(next.fireTime()) == today) "Today" else Fmt.date(Fmt.localDate(next.fireTime()))} at ${Fmt.time(next.fireTime())}")
                            } else Text("Nothing upcoming right now.", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
                item {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                        Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Today's progress", style = MaterialTheme.typography.titleMedium)
                            val frac = if (todays.isEmpty()) 0f else taken.toFloat() / todays.size
                            LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(10.dp)
                                .semantics { contentDescription = "$taken of ${todays.size} doses taken today" })
                            Text("$taken of ${todays.size} doses taken", style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
                if (upcoming.isNotEmpty()) {
                    item { SectionTitle("Upcoming reminders") }
                    items(upcoming, key = { "u${it.id}" }) { r ->
                        Text("${Fmt.time(r.fireTime())} — ${r.medicineName}, ${r.doseText}", style = MaterialTheme.typography.bodyLarge)
                    }
                }
                item { SectionTitle("Today's schedule") }
                if (todays.isEmpty()) item { Text("No doses are scheduled for today.", style = MaterialTheme.typography.bodyLarge) }
                val groups = todays.groupBy { periodOf(it.scheduledAt) }
                listOf("Morning", "Afternoon", "Evening", "Night").forEach { p ->
                    val list = groups[p]
                    if (!list.isNullOrEmpty()) {
                        item(key = "h$p") { Text(p, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary) }
                        items(list, key = { it.id }) { r ->
                            DoseCard(r, now, onClick = { selectedId = r.id }, onTaken = { vm.taken(r.id) })
                        }
                    }
                }
            }
        }
    }

    doses.find { it.id == selectedId }?.let { r ->
        DoseDialog(
            r, vm.events(r.id), onDismiss = { selectedId = null },
            onTaken = { vm.taken(r.id); selectedId = null },
            onSnooze = { vm.snooze(r.id, it); selectedId = null },
            onSkip = { vm.skip(r.id, it); selectedId = null },
            onCorrect = { s, reason -> vm.correct(r.id, s, reason); selectedId = null }
        )
    }
}
