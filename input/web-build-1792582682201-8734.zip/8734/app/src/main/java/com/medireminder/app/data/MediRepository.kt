package com.medireminder.app.data

import android.content.Context
import androidx.room.withTransaction
import com.medireminder.app.reminders.AlarmScheduler
import com.medireminder.app.reminders.AlarmService
import com.medireminder.app.reminders.Notifier
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.time.ZoneId

class MediRepository(
    private val ctx: Context,
    private val db: AppDatabase,
    val settings: SettingsStore,
    private val scheduler: AlarmScheduler,
    private val notifier: Notifier
) {
    private val medDao = db.medicineDao()
    private val schedDao = db.scheduleDao()
    private val doseDao = db.doseDao()
    private val mutex = Mutex()

    // ---- Observation -------------------------------------------------------------------------
    val medicines: Flow<List<Medicine>> = medDao.observeAll()
    val schedules: Flow<List<Schedule>> = schedDao.observeAll()
    fun observeMedicine(id: Long) = medDao.observe(id)
    fun observeSchedule(id: Long) = schedDao.observeForMedicine(id)
    fun observeDoses(from: Long, to: Long) = doseDao.observeRange(from, to)
    fun observeUpcoming(mid: Long) = doseDao.observeUpcoming(mid)
    fun observeRecentHistory(mid: Long) = doseDao.observeRecentHistory(mid)
    fun observeEvents(recordId: Long) = doseDao.observeEvents(recordId)
    suspend fun getMedicine(id: Long) = medDao.get(id)
    suspend fun getSchedule(mid: Long) = schedDao.forMedicine(mid).firstOrNull()

    // ---- Medicine management -----------------------------------------------------------------
    suspend fun saveMedicine(m: Medicine, input: ScheduleInput): Long {
        val now = System.currentTimeMillis()
        val id = db.withTransaction {
            if (m.id == 0L) {
                val mid = medDao.insert(m.copy(createdAt = now, updatedAt = now))
                schedDao.insert(
                    Schedule(
                        medicineId = mid, frequency = input.frequency, weekdaysMask = input.mask,
                        timesCsv = input.times.sorted().joinToString(","),
                        startDay = m.startDay, endDay = m.endDay, effectiveFrom = now
                    )
                )
                mid
            } else {
                medDao.update(m.copy(updatedAt = now))
                val existing = schedDao.forMedicine(m.id).firstOrNull()
                val sc = Schedule(
                    id = existing?.id ?: 0, medicineId = m.id, frequency = input.frequency,
                    weekdaysMask = input.mask, timesCsv = input.times.sorted().joinToString(","),
                    startDay = m.startDay, endDay = m.endDay, effectiveFrom = now
                )
                if (existing != null) schedDao.update(sc) else schedDao.insert(sc)
                m.id
            }
        }
        rebuildFuture(id)
        return id
    }

    suspend fun setActive(id: Long, active: Boolean) {
        val now = System.currentTimeMillis()
        mutex.withLock {
            medDao.setActive(id, active, now)
            if (!active) {
                val pending = doseDao.pendingForMedicine(id)
                pending.forEach { scheduler.cancel(it.id); notifier.cancel(it.id) }
                doseDao.deleteByIds(pending.map { it.id })
            } else {
                schedDao.touch(id, now)
            }
            syncLocked(now)
        }
    }

    suspend fun deleteMedicine(id: Long) {
        mutex.withLock {
            doseDao.pendingForMedicine(id).forEach { scheduler.cancel(it.id); notifier.cancel(it.id) }
            medDao.delete(id) // cascades to schedules, dose records and events
        }
    }

    // ---- Dose actions ------------------------------------------------------------------------
    suspend fun markTaken(id: Long): Boolean = mutex.withLock {
        val now = System.currentTimeMillis()
        val changed = db.withTransaction {
            val n = doseDao.takenIfPending(id, now) // only succeeds once: repeated taps are no-ops
            if (n > 0) {
                doseDao.insertEvent(DoseEvent(recordId = id, fromStatus = Status.PENDING, toStatus = Status.TAKEN, at = now))
                doseDao.get(id)?.let { stockDelta(it, -1) }
            }
            n > 0
        }
        scheduler.cancel(id); notifier.cancel(id)
        changed
    }

    suspend fun skip(id: Long, reason: String?): Boolean = mutex.withLock {
        val now = System.currentTimeMillis()
        val changed = db.withTransaction {
            val n = doseDao.skippedIfPending(id, now, reason?.trim()?.ifBlank { null })
            if (n > 0) doseDao.insertEvent(DoseEvent(recordId = id, fromStatus = Status.PENDING, toStatus = Status.SKIPPED, at = now))
            n > 0
        }
        scheduler.cancel(id); notifier.cancel(id)
        changed
    }

    suspend fun snooze(id: Long, minutes: Int) {
        mutex.withLock {
            val until = System.currentTimeMillis() + minutes * 60_000L
            if (doseDao.snooze(id, until) > 0) scheduler.schedule(id, until)
            notifier.cancel(id)
        }
    }

    /** Correct an earlier action. The change is logged in dose_events; nothing is silently overwritten. */
    suspend fun correct(id: Long, newStatus: String, reason: String?) {
        mutex.withLock {
            val r = doseDao.get(id) ?: return
            if (r.status == newStatus) return
            val now = System.currentTimeMillis()
            db.withTransaction {
                val t = if (newStatus == Status.MISSED) null else now
                val rs = if (newStatus == Status.SKIPPED) reason?.trim()?.ifBlank { null } else null
                doseDao.setStatus(id, newStatus, t, rs)
                doseDao.insertEvent(DoseEvent(recordId = id, fromStatus = r.status, toStatus = newStatus, at = now))
                if (r.status == Status.TAKEN) stockDelta(r, +1)
                if (newStatus == Status.TAKEN) stockDelta(r, -1)
            }
            scheduler.cancel(id); notifier.cancel(id)
        }
    }

    suspend fun getDose(id: Long) = doseDao.get(id)

    suspend fun setStock(id: Long, value: Double?) { medDao.setStock(id, value) }

    private suspend fun stockDelta(r: DoseRecord, sign: Int) {
        val m = medDao.get(r.medicineId) ?: return
        medDao.adjustStock(m.id, sign * parseQty(m.doseAmount))
    }

    /** Ring again later without clearing the notification (used when an alarm goes unanswered). */
    suspend fun reRing(id: Long, minutes: Int) {
        mutex.withLock {
            val until = System.currentTimeMillis() + minutes * 60_000L
            if (doseDao.snooze(id, until) > 0) scheduler.schedule(id, until)
        }
    }

    suspend fun reportText(days: Int): String {
        val today = LocalDate.now()
        val from = today.minusDays((days - 1).toLong())
        val list = doseDao.rangeList(dayStartMillis(from), dayStartMillis(today.plusDays(1)))
        val sb = StringBuilder()
        sb.append("MediReminder dose report\n${Fmt.date(from)} to ${Fmt.date(today)}\n")
        sb.append("Based on entries made by the user. This is not medical advice.\n\n")
        if (list.isEmpty()) sb.append("No doses recorded.\n")
        for (r in list) {
            val st = when (r.status) {
                Status.TAKEN -> "Taken" + (r.actedAt?.let { " (confirmed ${Fmt.time(it)})" } ?: "")
                Status.SKIPPED -> "Skipped" + (r.skipReason?.let { " - $it" } ?: "")
                Status.MISSED -> "Missed"
                else -> "Pending"
            }
            sb.append("${Fmt.dateTime(r.scheduledAt)} - ${r.medicineName} ${r.doseText}: $st\n")
        }
        return sb.toString()
    }

    // ---- Alarm engine ------------------------------------------------------------------------
    /** Called by the alarm receiver when a reminder is due. */
    suspend fun fire(id: Long) {
        mutex.withLock {
            val r = doseDao.get(id) ?: return
            if (r.status != Status.PENDING) return
            val s = settings.current()
            val ringing = s.alarmMode &&
                AlarmService.start(ctx, r.id, r.medicineName, r.doseText, r.scheduledAt, r.instructions, s)
            if (!ringing) notifier.show(r, s)
            doseDao.setNotified(id, System.currentTimeMillis())
        }
    }

    /** Marks overdue doses missed, creates upcoming dose records and (re)registers alarms. Idempotent. */
    suspend fun sync() { mutex.withLock { syncLocked(System.currentTimeMillis()) } }

    /** Drops future, not-yet-notified doses and regenerates them (schedule edits, time-zone change). */
    suspend fun rebuildFuture(medicineId: Long?) {
        mutex.withLock {
            val now = System.currentTimeMillis()
            val stale = doseDao.futureUnnotified(now, medicineId)
            stale.forEach { scheduler.cancel(it.id) }
            doseDao.deleteByIds(stale.map { it.id })
            syncLocked(now)
        }
    }

    private suspend fun syncLocked(now: Long) {
        val s = settings.current()
        val graceMs = s.graceMin * 60_000L

        // 1. Missed doses (no confirmation within the grace period).
        for (id in doseDao.overdueIds(now, graceMs)) {
            db.withTransaction {
                doseDao.setStatus(id, Status.MISSED, null, null)
                doseDao.insertEvent(DoseEvent(recordId = id, fromStatus = Status.PENDING, toStatus = Status.MISSED, at = now))
            }
            scheduler.cancel(id); notifier.cancel(id)
        }

        // 2. Materialise one record per scheduled occurrence for today and the next two days.
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val meds = medDao.getActive().associateBy { it.id }
        val schedules = schedDao.enabledAll()
        for (offset in 0..2) {
            val date = today.plusDays(offset.toLong())
            for (sc in schedules) {
                val med = meds[sc.medicineId] ?: continue
                if (!covers(sc, date)) continue
                for (min in sc.times()) {
                    val at = date.atTime(min / 60, min % 60).atZone(zone).toInstant().toEpochMilli()
                    if (at < sc.effectiveFrom) continue
                    doseDao.insertIgnore(
                        DoseRecord(
                            medicineId = med.id, scheduleId = sc.id,
                            occurrenceId = "${sc.id}-${date.toEpochDay()}-$min",
                            scheduledAt = at, medicineName = med.name,
                            doseText = "${med.doseAmount} ${med.doseUnit}".trim(),
                            instructions = instructionsOf(med)
                        )
                    )
                }
            }
        }

        // 3. One alarm per pending dose (stable request code = record id, so no duplicates).
        val pending = doseDao.pending()
        val overdueUnnotified = pending
            .filter { it.fireTime() <= now && it.notifiedAt == null }
            .sortedByDescending { it.scheduledAt }
        val allowed = overdueUnnotified.take(3).map { it.id }.toSet() // avoid a flood after being offline
        for (r in pending) {
            val fire = r.fireTime()
            when {
                fire > now -> scheduler.schedule(r.id, fire)
                r.notifiedAt == null && r.id in allowed -> scheduler.schedule(r.id, now + 1500)
                r.notifiedAt == null -> doseDao.setNotified(r.id, now) // too old: stays on dashboard silently
                else -> scheduler.cancel(r.id)
            }
        }
    }

    private fun covers(sc: Schedule, date: LocalDate): Boolean {
        val d = date.toEpochDay()
        if (d < sc.startDay) return false
        val end = sc.endDay
        if (end != null && d > end) return false
        if (sc.frequency == "WEEKDAYS" && ((sc.weekdaysMask shr (date.dayOfWeek.value - 1)) and 1) == 0) return false
        return true
    }

    private fun instructionsOf(m: Medicine): String {
        val parts = mutableListOf<String>()
        if (m.strength.isNotBlank()) parts += m.strength
        if (m.food != "Unspecified") parts += m.food
        if (m.notes.isNotBlank()) parts += m.notes
        return parts.joinToString(" · ")
    }
}
