@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.medireminder.app.ui

import android.text.format.DateFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medireminder.app.data.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private val FORMS = listOf("Tablet", "Capsule", "Liquid", "Drops", "Inhaler", "Injection", "Other")
private val FOODS = listOf("Unspecified", "Before food", "After food", "With food")
private val UNIT_SUGGESTIONS = listOf("tablet", "capsule", "mL", "drops", "puffs", "units")

@Composable
private fun ErrorText(msg: String?) {
    if (msg != null) Text(msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
}

@Composable
private fun DateButton(label: String, date: LocalDate, onPick: (LocalDate) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
        Text("$label: ${Fmt.date(date)}")
    }
    if (show) {
        val st = rememberDatePickerState(initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                    show = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } }
        ) { DatePicker(state = st) }
    }
}

@Composable
private fun TimeDialog(onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val ctx = LocalContext.current
    val st = rememberTimePickerState(initialHour = 8, initialMinute = 0, is24Hour = DateFormat.is24HourFormat(ctx))
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = { onConfirm(st.hour * 60 + st.minute) }) { Text("Add time") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        text = { TimePicker(state = st) }
    )
}

@Composable
fun AddEditScreen(onBack: () -> Unit, onSaved: (Long) -> Unit, vm: AddEditViewModel = viewModel()) {
    var showTime by remember { mutableStateOf(false) }
    val e = vm.errors
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (vm.id > 0) "Edit medicine" else "Add medicine") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
            )
        }
    ) { pad ->
        if (!vm.loaded) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp).imePadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Enter your medicine exactly as written on your prescription or label.", style = MaterialTheme.typography.bodyMedium)

            OutlinedTextField(vm.name, { vm.name = it }, label = { Text("Medicine name *") }, singleLine = true,
                isError = e["name"] != null, modifier = Modifier.fillMaxWidth())
            ErrorText(e["name"])

            OutlinedTextField(vm.strength, { vm.strength = it }, label = { Text("Strength (optional, e.g. 500 mg)") }, singleLine = true,
                supportingText = { Text("The amount of medicine in each tablet or mL — not how much you take.") },
                modifier = Modifier.fillMaxWidth())

            DropdownField("Form", vm.form, FORMS) { vm.form = it }

            Text("Dose to take *", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(vm.amount, { vm.amount = it }, label = { Text("Amount") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = e["amount"] != null, modifier = Modifier.weight(1f))
                OutlinedTextField(vm.unit, { vm.unit = it }, label = { Text("Unit") }, singleLine = true,
                    isError = e["unit"] != null, modifier = Modifier.weight(1f))
            }
            ErrorText(e["amount"]); ErrorText(e["unit"])
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                UNIT_SUGGESTIONS.forEach { u -> AssistChip(onClick = { vm.unit = u }, label = { Text(u) }) }
            }

            DropdownField("Food instructions", vm.food, FOODS) { vm.food = it }

            Text("Schedule *", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = vm.frequency == "DAILY", onClick = { vm.frequency = "DAILY" }, label = { Text("Every day") })
                FilterChip(selected = vm.frequency == "WEEKDAYS", onClick = { vm.frequency = "WEEKDAYS" }, label = { Text("Selected weekdays") })
            }
            if (vm.frequency == "WEEKDAYS") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WEEKDAY_NAMES.forEachIndexed { i, n ->
                        FilterChip(selected = (vm.mask shr i) and 1 == 1, onClick = { vm.toggleDay(i) }, label = { Text(n) })
                    }
                }
                ErrorText(e["days"])
            }

            Text("Reminder times", style = MaterialTheme.typography.titleSmall)
            vm.times.toList().forEach { t ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(Fmt.minutes(t), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.times.remove(t) }) { Icon(Icons.Filled.Close, "Remove reminder at ${Fmt.minutes(t)}") }
                }
            }
            OutlinedButton(onClick = { showTime = true }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Add reminder time") }
            ErrorText(e["times"])

            DateButton("Start date", vm.startDate) { vm.startDate = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ongoing (no end date)", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                Switch(checked = !vm.hasEnd, onCheckedChange = { vm.hasEnd = !it })
            }
            if (vm.hasEnd) DateButton("End date", vm.endDate) { vm.endDate = it }
            ErrorText(e["end"])

            OutlinedTextField(vm.notes, { vm.notes = it }, label = { Text("Notes (optional)") }, minLines = 2, modifier = Modifier.fillMaxWidth())

            Button(onClick = { vm.save(onSaved) }, enabled = !vm.saving, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
                Text(if (vm.id > 0) "Save changes" else "Save medicine")
            }
            Text("MediReminder only reminds you. It does not give medical advice.", style = MaterialTheme.typography.bodySmall)
        }
    }
    if (showTime) TimeDialog(onDismiss = { showTime = false }, onConfirm = { vm.addTime(it); showTime = false })
}
