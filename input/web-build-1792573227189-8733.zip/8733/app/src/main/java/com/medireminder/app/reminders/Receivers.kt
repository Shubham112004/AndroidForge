package com.medireminder.app.reminders

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.medireminder.app.MediReminderApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private fun BroadcastReceiver.runAsync(block: suspend () -> Unit) {
    val result = goAsync()
    CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
        try { block() } finally { result.finish() }
    }
}

private fun Context.repo() = (applicationContext as MediReminderApp).repo

/** Fires when a dose is due. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        if (id < 0) return
        val repo = context.repo()
        runAsync { repo.fire(id) }
    }
}

/** Handles the Taken / Snooze / Skip buttons; works while the app is closed. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        if (id < 0) return
        val repo = context.repo()
        val action = intent.action
        runAsync {
            when (action) {
                ACTION_TAKEN -> repo.markTaken(id)
                ACTION_SKIP -> repo.skip(id, null)
                ACTION_SNOOZE -> repo.snooze(id, repo.settings.current().snoozeMin)
                else -> Unit
            }
        }
    }

    companion object {
        const val ACTION_TAKEN = "com.medireminder.app.TAKEN"
        const val ACTION_SNOOZE = "com.medireminder.app.SNOOZE"
        const val ACTION_SKIP = "com.medireminder.app.SKIP"
    }
}

/** Reboot, app update, clock / time-zone change, exact-alarm permission change. */
class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val repo = context.repo()
        val action = intent.action
        runAsync {
            if (action == Intent.ACTION_TIMEZONE_CHANGED) repo.rebuildFuture(null) else repo.sync()
        }
    }
}
