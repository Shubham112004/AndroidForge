package com.medireminder.app.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle

object Fmt {
    private val timeF: DateTimeFormatter = DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT)
    private val dateF: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, d MMM yyyy")

    fun minutes(min: Int): String = LocalTime.of(min / 60, min % 60).format(timeF)
    fun time(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalTime().format(timeF)
    fun date(d: LocalDate): String = d.format(dateF)
    fun localDate(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    fun dateTime(ms: Long): String = "${date(localDate(ms))}, ${time(ms)}"
    fun epochDay(day: Long): String = date(LocalDate.ofEpochDay(day))
}

fun dayStartMillis(d: LocalDate): Long = d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

fun mondayOf(d: LocalDate): LocalDate = d.minusDays((d.dayOfWeek.value - DayOfWeek.MONDAY.value).toLong())

val WEEKDAY_NAMES = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

fun weekdaysText(mask: Int): String =
    WEEKDAY_NAMES.filterIndexed { i, _ -> (mask shr i) and 1 == 1 }.joinToString(", ")

fun scheduleSummary(s: Schedule?): String {
    if (s == null) return "No schedule"
    val days = if (s.frequency == "DAILY") "Every day" else weekdaysText(s.weekdaysMask)
    return days + " at " + s.times().joinToString(", ") { Fmt.minutes(it) }
}

fun periodOf(ms: Long): String {
    val h = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).hour
    return when (h) {
        in 5..11 -> "Morning"
        in 12..16 -> "Afternoon"
        in 17..20 -> "Evening"
        else -> "Night"
    }
}
