package com.medireminder.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

data class AppSettings(
    val sound: Boolean = true,
    val vibrate: Boolean = true,
    val snoozeMin: Int = 10,
    val graceMin: Int = 60,
    val theme: String = "SYSTEM" // SYSTEM, LIGHT, DARK
)

class SettingsStore(private val ctx: Context) {
    private object K {
        val SOUND = booleanPreferencesKey("sound")
        val VIBRATE = booleanPreferencesKey("vibrate")
        val SNOOZE = intPreferencesKey("snooze_min")
        val GRACE = intPreferencesKey("grace_min")
        val THEME = stringPreferencesKey("theme")
    }

    val flow: Flow<AppSettings> = ctx.dataStore.data.map { p ->
        AppSettings(
            sound = p[K.SOUND] ?: true,
            vibrate = p[K.VIBRATE] ?: true,
            snoozeMin = p[K.SNOOZE] ?: 10,
            graceMin = p[K.GRACE] ?: 60,
            theme = p[K.THEME] ?: "SYSTEM"
        )
    }

    suspend fun current(): AppSettings = flow.first()
    suspend fun setSound(v: Boolean) { ctx.dataStore.edit { it[K.SOUND] = v } }
    suspend fun setVibrate(v: Boolean) { ctx.dataStore.edit { it[K.VIBRATE] = v } }
    suspend fun setSnooze(v: Int) { ctx.dataStore.edit { it[K.SNOOZE] = v } }
    suspend fun setGrace(v: Int) { ctx.dataStore.edit { it[K.GRACE] = v } }
    suspend fun setTheme(v: String) { ctx.dataStore.edit { it[K.THEME] = v } }
}
