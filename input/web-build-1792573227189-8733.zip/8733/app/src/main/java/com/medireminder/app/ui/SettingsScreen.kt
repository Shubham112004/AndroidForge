@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.medireminder.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medireminder.app.reminders.AlarmScheduler

@Composable
private fun Group(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.heightIn(min = 48.dp)) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel()) {
    val s by vm.settings.collectAsState()
    val ctx = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, ev -> if (ev == Lifecycle.Event.ON_RESUME) refresh++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val notifOn = remember(refresh) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val exactOn = remember(refresh) { AlarmScheduler.canExact(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0.0" }

    fun open(i: Intent) { runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    fun notificationSettings() = open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))

    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = { TopAppBar(title = { Text("Settings") }) }) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Group("Reminders") {
                SwitchRow("Sound", s.sound, vm::sound)
                SwitchRow("Vibration", s.vibrate, vm::vibrate)
                Text("Default snooze for the notification button", style = MaterialTheme.typography.bodyLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 10, 15).forEach { m -> FilterChip(selected = s.snoozeMin == m, onClick = { vm.snooze(m) }, label = { Text("$m min") }) }
                }
                Text("Mark a dose as missed after", style = MaterialTheme.typography.bodyLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 60, 120).forEach { m -> FilterChip(selected = s.graceMin == m, onClick = { vm.grace(m) }, label = { Text("$m min") }) }
                }
            }
            Group("Theme") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("SYSTEM" to "System", "LIGHT" to "Light", "DARK" to "Dark").forEach { (k, v) ->
                        FilterChip(selected = s.theme == k, onClick = { vm.theme(k) }, label = { Text(v) })
                    }
                }
            }
            Group("Permissions") {
                Text("Notifications: " + if (notifOn) "Allowed" else "Not allowed", style = MaterialTheme.typography.bodyLarge)
                if (!notifOn && Build.VERSION.SDK_INT >= 33)
                    Button(onClick = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Allow notifications") }
                OutlinedButton(onClick = { notificationSettings() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Open notification settings") }
                if (Build.VERSION.SDK_INT >= 31) {
                    Text("Exact alarms: " + if (exactOn) "Allowed" else "Not allowed (reminders may be a few minutes late)", style = MaterialTheme.typography.bodyLarge)
                    OutlinedButton(
                        onClick = { open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))) },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) { Text("Open alarm permission settings") }
                }
                OutlinedButton(onClick = { open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.heightIn(min = 48.dp)) {
                    Text("Open battery optimization settings")
                }
                Text(
                    "Some phone makers limit background apps. If reminders arrive late or not at all, allow MediReminder to run without battery restrictions. Reminders cannot be guaranteed on every device.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Group("Privacy") {
                Text(
                    "Everything you enter stays on this phone. MediReminder has no account, no server and no internet access, and it shares nothing with anyone. " +
                        "Deleting a medicine or uninstalling the app removes its data.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "MediReminder is a reminder and tracking tool, not medical advice. It only shows the instructions you entered. " +
                        "If you miss a dose, follow your prescription instructions or ask your doctor or pharmacist.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            Text("MediReminder version $version", style = MaterialTheme.typography.bodySmall)
        }
    }
}
