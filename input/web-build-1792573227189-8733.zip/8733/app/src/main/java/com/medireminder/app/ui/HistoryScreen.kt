@file:OptIn(ExperimentalMaterial3Api::class)

package com.medireminder.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.medireminder.app.data.*

@Composable
fun HistoryScreen(vm: HistoryViewModel = viewModel()) {
    val date by vm.date.collectAsState()
    val weekly by vm.weekly.collectAsState()
    val filter by vm.filter.collectAsState()
    val meds by vm.medicines.collectAsState()
    val records by vm.records.collectAsState()
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val now = System.currentTimeMillis()
    val label = if (weekly) "${Fmt.date(mondayOf(date))} – ${Fmt.date(mondayOf(date).plusDays(6))}" else Fmt.date(date)
    val filterName = meds.find { it.id == filter }?.name ?: "All medicines"

    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = { TopAppBar(title = { Text("History") }) }) { pad ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 8.dp, 16.dp, pad.calculateBottomPadding() + 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !weekly, onClick = { vm.weekly.value = false }, label = { Text("Daily") })
                    FilterChip(selected = weekly, onClick = { vm.weekly.value = true }, label = { Text("Weekly") })
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { vm.shift(-1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Previous ${if (weekly) "week" else "day"}") }
                    Text(label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.shift(1) }) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Next ${if (weekly) "week" else "day"}") }
                }
            }
            item { DropdownField("Medicine", filterName, listOf("All medicines") + meds.map { it.name }) { sel ->
                vm.filter.value = meds.find { it.name == sel }?.id
            } }
            if (records.isEmpty()) item { Text("No doses recorded for this period.", style = MaterialTheme.typography.bodyLarge) }
            items(records, key = { it.id }) { r ->
                DoseCard(r, now, showDate = weekly, onClick = { selectedId = r.id }, onTaken = { vm.taken(r.id) })
            }
        }
    }

    records.find { it.id == selectedId }?.let { r ->
        DoseDialog(r, vm.events(r.id), onDismiss = { selectedId = null },
            onTaken = { vm.taken(r.id); selectedId = null },
            onSnooze = { vm.snooze(r.id, it); selectedId = null },
            onSkip = { vm.skip(r.id, it); selectedId = null },
            onCorrect = { s, reason -> vm.correct(r.id, s, reason); selectedId = null })
    }
}
