package com.medireminder.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

object Status {
    const val PENDING = "PENDING"
    const val TAKEN = "TAKEN"
    const val SKIPPED = "SKIPPED"
    const val MISSED = "MISSED"
}

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val strength: String = "",
    val form: String = "Tablet",
    val doseAmount: String,
    val doseUnit: String,
    val food: String = "Unspecified",
    val notes: String = "",
    val startDay: Long,          // epoch day
    val endDay: Long? = null,    // epoch day, null = ongoing
    val active: Boolean = true,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "schedules",
    foreignKeys = [ForeignKey(
        entity = Medicine::class, parentColumns = ["id"],
        childColumns = ["medicineId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("medicineId")]
)
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val frequency: String,       // "DAILY" or "WEEKDAYS"
    val weekdaysMask: Int,       // bit0 = Monday ... bit6 = Sunday
    val timesCsv: String,        // minutes after midnight, comma separated
    val startDay: Long,
    val endDay: Long?,
    val enabled: Boolean = true,
    val effectiveFrom: Long      // doses scheduled before this instant are never generated
)

@Entity(
    tableName = "dose_records",
    foreignKeys = [ForeignKey(
        entity = Medicine::class, parentColumns = ["id"],
        childColumns = ["medicineId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [
        Index("medicineId"), Index("scheduleId"), Index("scheduledAt"),
        Index(value = ["occurrenceId"], unique = true)
    ]
)
data class DoseRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val scheduleId: Long,
    val occurrenceId: String,    // "<scheduleId>-<epochDay>-<minuteOfDay>"
    val scheduledAt: Long,
    val status: String = Status.PENDING,
    val actedAt: Long? = null,
    val skipReason: String? = null,
    val snoozedUntil: Long? = null,
    val notifiedAt: Long? = null,
    // Snapshot at creation time so later edits never rewrite history.
    val medicineName: String,
    val doseText: String,
    val instructions: String
)

/** Audit trail: every status change is logged, so corrections never destroy the original record. */
@Entity(
    tableName = "dose_events",
    foreignKeys = [ForeignKey(
        entity = DoseRecord::class, parentColumns = ["id"],
        childColumns = ["recordId"], onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("recordId")]
)
data class DoseEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recordId: Long,
    val fromStatus: String,
    val toStatus: String,
    val at: Long
)

data class ScheduleInput(val frequency: String, val mask: Int, val times: List<Int>)

fun Schedule.times(): List<Int> =
    timesCsv.split(",").mapNotNull { it.trim().toIntOrNull() }.sorted()

fun DoseRecord.fireTime(): Long = snoozedUntil ?: scheduledAt
