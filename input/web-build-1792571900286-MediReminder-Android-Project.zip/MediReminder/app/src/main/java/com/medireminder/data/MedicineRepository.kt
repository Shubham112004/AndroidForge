package com.medireminder.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.*
import java.time.format.DateTimeFormatter
import com.medireminder.reminder.ReminderScheduler

private val Context.dataStore by preferencesDataStore(name = "medi_preferences")

class MedicineRepository(private val medicineDao: MedicineDao, private val doseDao: DoseDao, private val context: Context) {
    val medicines = medicineDao.observeAll()
    val settings: Flow<AppSettings> = context.dataStore.data.map { p -> AppSettings(theme = p[stringPreferencesKey("theme")] ?: "System", snoozeMinutes = (p[stringPreferencesKey("snooze")] ?: "10").toIntOrNull() ?: 10, graceMinutes = (p[stringPreferencesKey("grace")] ?: "60").toIntOrNull() ?: 60, soundEnabled = (p[stringPreferencesKey("sound")] ?: "true").toBoolean(), vibrationEnabled = (p[stringPreferencesKey("vibration")] ?: "true").toBoolean()) }
    suspend fun saveSettings(s: AppSettings) { context.dataStore.edit { p -> p[stringPreferencesKey("theme")]=s.theme; p[stringPreferencesKey("snooze")]=s.snoozeMinutes.toString(); p[stringPreferencesKey("grace")]=s.graceMinutes.toString(); p[stringPreferencesKey("sound")]=s.soundEnabled.toString(); p[stringPreferencesKey("vibration")]=s.vibrationEnabled.toString() } }
    suspend fun add(m: Medicine, times: String, frequency: String, weekdays: String): Long {
        val id = medicineDao.insert(m)
        medicineDao.insertSchedule(MedicationSchedule(medicineId=id, times=times, frequency=frequency, weekdays=weekdays))
        return id
    }
    suspend fun edit(m: Medicine, times: String, frequency: String, weekdays: String) {
        medicineDao.update(m.copy(updatedAt=System.currentTimeMillis()))
        medicineDao.deleteSchedules(m.id)
        medicineDao.insertSchedule(MedicationSchedule(medicineId=m.id, times=times, frequency=frequency, weekdays=weekdays))
    }
    suspend fun medicine(id: Long) = medicineDao.get(id)
    suspend fun schedules(id: Long) = medicineDao.schedules(id)
    suspend fun delete(m: Medicine) { medicineDao.delete(m) }
    suspend fun setActive(m: Medicine, active: Boolean) = medicineDao.update(m.copy(active=active, updatedAt=System.currentTimeMillis()))
    fun doses(from: Long, to: Long) = doseDao.observeRange(from, to)
    suspend fun recent(id: Long) = doseDao.recent(id)
    suspend fun recordDose(key: String, status: String, reason: String = "") {
        val old = doseDao.getOccurrence(key) ?: return
        if (old.status == "TAKEN" && status == "TAKEN") return
        doseDao.updateStatus(key, status, if (status == "TAKEN") System.currentTimeMillis() else null, reason)
    }
    suspend fun ensureOccurrence(medicineId: Long, scheduleId: Long, at: Long) {
        val key = "$medicineId:$scheduleId:$at"
        doseDao.insert(DoseRecord(medicineId=medicineId, scheduleId=scheduleId, occurrenceId=key, scheduledAt=at))
    }
    suspend fun activeMedicines() = medicineDao.active()
    suspend fun reconcileFuture(days: Int = 7) {
        val now = LocalDate.now(); val until = now.plusDays(days.toLong())
        medicineDao.active().forEach { m ->
            if (m.endDate.isNotBlank() && runCatching { LocalDate.parse(m.endDate).isBefore(now) }.getOrDefault(false)) return@forEach
            medicineDao.schedules(m.id).filter { it.enabled }.forEach { s ->
                val times = s.times.split(",").mapNotNull { it.trim().takeIf(String::isNotBlank) }
                var d = maxOf(now, runCatching { LocalDate.parse(m.startDate) }.getOrDefault(now))
                while (!d.isAfter(until)) {
                    val day = d.dayOfWeek.value
                    val selected = s.weekdays.split(",").mapNotNull { it.toIntOrNull() }.contains(day)
                    if (selected && (m.endDate.isBlank() || !d.isAfter(runCatching { LocalDate.parse(m.endDate) }.getOrDefault(until)))) {
                        times.forEach { t -> runCatching { val lt = LocalTime.parse(t); val at = d.atTime(lt).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(); if (at >= System.currentTimeMillis()-2*60_000L) { ensureOccurrence(m.id,s.id,at); val key = "${m.id}:${s.id}:$at"; ReminderScheduler(context, this).scheduleOccurrence(key, m.name, "${m.doseAmount} ${m.doseUnit}${if (m.strength.isNotBlank()) " • ${m.strength}" else ""}", at) } } }
                    }
                    d=d.plusDays(1)
                }
            }
        }
    }
}
