# MediReminder (Android V1)

Native Android project using Kotlin, Jetpack Compose, Material 3, Room, DataStore, WorkManager and AlarmManager.

## Open and build

1. Install Android Studio (stable) with Android SDK Platform 35 and JDK 17.
2. Open the `MediReminder` folder in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Build using **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `./gradlew assembleDebug` if you add the Gradle wrapper for your local installation.
5. The debug APK is normally generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Included

- Compose dashboard, medicine list, add/edit medicine form, medicine details, dose history and settings.
- Local Room entities/DAOs for medicines, schedules, dose records and settings.
- DataStore-backed reminder preferences.
- Android notification channel, notification action receiver, AlarmManager exact/inexact fallback, boot/time-change reconciliation worker.
- Local-only data design; no login or backend.

## Important implementation notes

- Android 13+ asks for notification permission. Android 12+ may require the user to allow exact alarms in system settings; when unavailable, alarms fall back to inexact scheduling.
- OEM battery management, force-stop behavior, denied permissions and device shutdown can delay or prevent delivery.
- This source project is a V1 scaffold and needs a local Android SDK/Gradle build before installation. The current build environment did not include the Android SDK or Gradle executable, so no APK is included.
- The reminder scheduling integration and status/history reconciliation are not yet production-complete: notification action IDs, snooze handling, automatic missed-dose reconciliation, historical record preservation on deletion, and dynamic sound/vibration/theme behavior need follow-up implementation before relying on this for real medication use. Use it as a personal prototype only, not as the sole source of medication instructions.
